(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./0l1xih4f.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0l1xih4f.entry.js",
		"common",
		57
	],
	"./0l1xih4f.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0l1xih4f.sc.entry.js",
		"common",
		58
	],
	"./2vnnvwad.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2vnnvwad.entry.js",
		"common",
		9
	],
	"./2vnnvwad.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2vnnvwad.sc.entry.js",
		"common",
		10
	],
	"./4j0bvo7f.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4j0bvo7f.entry.js",
		"common",
		113
	],
	"./4j0bvo7f.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4j0bvo7f.sc.entry.js",
		"common",
		114
	],
	"./5c6i2c9u.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5c6i2c9u.entry.js",
		"common",
		59
	],
	"./5c6i2c9u.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5c6i2c9u.sc.entry.js",
		"common",
		60
	],
	"./5dcephfe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5dcephfe.entry.js",
		"common",
		11
	],
	"./5dcephfe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5dcephfe.sc.entry.js",
		"common",
		12
	],
	"./5wsmecfc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5wsmecfc.entry.js",
		0,
		"common",
		131
	],
	"./5wsmecfc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5wsmecfc.sc.entry.js",
		0,
		"common",
		132
	],
	"./6zvyjie1.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6zvyjie1.entry.js",
		0,
		"common",
		133
	],
	"./6zvyjie1.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6zvyjie1.sc.entry.js",
		0,
		"common",
		134
	],
	"./6zze4vuo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6zze4vuo.entry.js",
		"common",
		13
	],
	"./6zze4vuo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6zze4vuo.sc.entry.js",
		"common",
		14
	],
	"./7alfy39y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7alfy39y.entry.js",
		"common",
		15
	],
	"./7alfy39y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7alfy39y.sc.entry.js",
		"common",
		16
	],
	"./7fcfpjrn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7fcfpjrn.entry.js",
		"common",
		61
	],
	"./7fcfpjrn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7fcfpjrn.sc.entry.js",
		"common",
		62
	],
	"./9wrrczcy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9wrrczcy.entry.js",
		0,
		"common",
		135
	],
	"./9wrrczcy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9wrrczcy.sc.entry.js",
		0,
		"common",
		136
	],
	"./a9lbspgr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/a9lbspgr.entry.js",
		"common",
		17
	],
	"./a9lbspgr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/a9lbspgr.sc.entry.js",
		"common",
		18
	],
	"./ansnwlsp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ansnwlsp.entry.js",
		"common",
		19
	],
	"./ansnwlsp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ansnwlsp.sc.entry.js",
		"common",
		20
	],
	"./bibcp1y9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bibcp1y9.entry.js",
		"common",
		63
	],
	"./bibcp1y9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bibcp1y9.sc.entry.js",
		"common",
		64
	],
	"./bme372jv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bme372jv.entry.js",
		"common",
		65
	],
	"./bme372jv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bme372jv.sc.entry.js",
		"common",
		66
	],
	"./bryrct1s.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bryrct1s.entry.js",
		"common",
		21
	],
	"./bryrct1s.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bryrct1s.sc.entry.js",
		"common",
		22
	],
	"./byl9czyj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/byl9czyj.entry.js",
		"common",
		67
	],
	"./byl9czyj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/byl9czyj.sc.entry.js",
		"common",
		68
	],
	"./cageonqo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cageonqo.entry.js",
		"common",
		23
	],
	"./cageonqo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cageonqo.sc.entry.js",
		"common",
		24
	],
	"./cbqf6ftj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cbqf6ftj.entry.js",
		"common",
		69
	],
	"./cbqf6ftj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cbqf6ftj.sc.entry.js",
		"common",
		70
	],
	"./chp2j6cq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/chp2j6cq.entry.js",
		"common",
		25
	],
	"./chp2j6cq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/chp2j6cq.sc.entry.js",
		"common",
		26
	],
	"./coiwaa5h.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/coiwaa5h.entry.js",
		0,
		"common",
		139
	],
	"./coiwaa5h.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/coiwaa5h.sc.entry.js",
		0,
		"common",
		140
	],
	"./cvpeu494.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cvpeu494.entry.js",
		"common",
		27
	],
	"./cvpeu494.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cvpeu494.sc.entry.js",
		"common",
		28
	],
	"./dyxhizh4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dyxhizh4.entry.js",
		"common",
		29
	],
	"./dyxhizh4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dyxhizh4.sc.entry.js",
		"common",
		30
	],
	"./eblkb2xe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eblkb2xe.entry.js",
		0,
		"common",
		141
	],
	"./eblkb2xe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eblkb2xe.sc.entry.js",
		0,
		"common",
		142
	],
	"./efupgb3t.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/efupgb3t.entry.js",
		"common",
		31
	],
	"./efupgb3t.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/efupgb3t.sc.entry.js",
		"common",
		32
	],
	"./ek70mjfu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ek70mjfu.entry.js",
		"common",
		33
	],
	"./ek70mjfu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ek70mjfu.sc.entry.js",
		"common",
		34
	],
	"./ezzlijza.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ezzlijza.entry.js",
		"common",
		35
	],
	"./ezzlijza.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ezzlijza.sc.entry.js",
		"common",
		36
	],
	"./ffukzwt6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.entry.js",
		"common",
		123
	],
	"./ffukzwt6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.sc.entry.js",
		"common",
		124
	],
	"./fiqi6app.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fiqi6app.entry.js",
		143
	],
	"./fiqi6app.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fiqi6app.sc.entry.js",
		144
	],
	"./g2to5rnb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g2to5rnb.entry.js",
		"common",
		37
	],
	"./g2to5rnb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g2to5rnb.sc.entry.js",
		"common",
		38
	],
	"./g6bzrzzd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g6bzrzzd.entry.js",
		"common",
		39
	],
	"./g6bzrzzd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g6bzrzzd.sc.entry.js",
		"common",
		40
	],
	"./gaj64apv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gaj64apv.entry.js",
		"common",
		75
	],
	"./gaj64apv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gaj64apv.sc.entry.js",
		"common",
		76
	],
	"./gksnkxfi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gksnkxfi.entry.js",
		"common",
		77
	],
	"./gksnkxfi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gksnkxfi.sc.entry.js",
		"common",
		78
	],
	"./he9083ts.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/he9083ts.entry.js",
		"common",
		125
	],
	"./he9083ts.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/he9083ts.sc.entry.js",
		"common",
		126
	],
	"./hm0yjz6v.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hm0yjz6v.entry.js",
		"common",
		71
	],
	"./hm0yjz6v.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hm0yjz6v.sc.entry.js",
		"common",
		72
	],
	"./hndgwhpb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hndgwhpb.entry.js",
		"common",
		127
	],
	"./hndgwhpb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hndgwhpb.sc.entry.js",
		"common",
		128
	],
	"./huoflabb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/huoflabb.entry.js",
		"common",
		79
	],
	"./huoflabb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/huoflabb.sc.entry.js",
		"common",
		80
	],
	"./i0gpae8e.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i0gpae8e.entry.js",
		2,
		"common",
		145
	],
	"./i0gpae8e.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i0gpae8e.sc.entry.js",
		2,
		"common",
		146
	],
	"./i1rfoh5j.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i1rfoh5j.entry.js",
		0,
		"common",
		147
	],
	"./i1rfoh5j.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i1rfoh5j.sc.entry.js",
		0,
		"common",
		148
	],
	"./ic12lvbr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ic12lvbr.entry.js",
		"common",
		81
	],
	"./ic12lvbr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ic12lvbr.sc.entry.js",
		"common",
		82
	],
	"./iq5jslpb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iq5jslpb.entry.js",
		0,
		"common",
		149
	],
	"./iq5jslpb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iq5jslpb.sc.entry.js",
		0,
		"common",
		150
	],
	"./iqiyzedq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqiyzedq.entry.js",
		"common",
		83
	],
	"./iqiyzedq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqiyzedq.sc.entry.js",
		"common",
		84
	],
	"./kzgfycox.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kzgfycox.entry.js",
		0,
		"common",
		151
	],
	"./kzgfycox.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kzgfycox.sc.entry.js",
		0,
		"common",
		152
	],
	"./lbr5dtex.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lbr5dtex.entry.js",
		"common",
		85
	],
	"./lbr5dtex.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lbr5dtex.sc.entry.js",
		"common",
		86
	],
	"./louxpirp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/louxpirp.entry.js",
		"common",
		87
	],
	"./louxpirp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/louxpirp.sc.entry.js",
		"common",
		88
	],
	"./lqsyrhxc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lqsyrhxc.entry.js",
		0,
		"common",
		115
	],
	"./lqsyrhxc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lqsyrhxc.sc.entry.js",
		0,
		"common",
		116
	],
	"./mazigaom.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mazigaom.entry.js",
		"common",
		89
	],
	"./mazigaom.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mazigaom.sc.entry.js",
		"common",
		90
	],
	"./mvmkvb0v.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mvmkvb0v.entry.js",
		"common",
		91
	],
	"./mvmkvb0v.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mvmkvb0v.sc.entry.js",
		"common",
		92
	],
	"./npjviern.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/npjviern.entry.js",
		"common",
		41
	],
	"./npjviern.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/npjviern.sc.entry.js",
		"common",
		42
	],
	"./o6wfoo8y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/o6wfoo8y.entry.js",
		153
	],
	"./o6wfoo8y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/o6wfoo8y.sc.entry.js",
		154
	],
	"./oekkqbcc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oekkqbcc.entry.js",
		0,
		"common",
		155
	],
	"./oekkqbcc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oekkqbcc.sc.entry.js",
		0,
		"common",
		156
	],
	"./pj94v4tn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pj94v4tn.entry.js",
		"common",
		43
	],
	"./pj94v4tn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pj94v4tn.sc.entry.js",
		"common",
		44
	],
	"./poqqlq92.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/poqqlq92.entry.js",
		0,
		"common",
		157
	],
	"./poqqlq92.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/poqqlq92.sc.entry.js",
		0,
		"common",
		158
	],
	"./ps95c88c.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ps95c88c.entry.js",
		2,
		"common",
		159
	],
	"./ps95c88c.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ps95c88c.sc.entry.js",
		2,
		"common",
		160
	],
	"./pwf4b0ct.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pwf4b0ct.entry.js",
		"common",
		45
	],
	"./pwf4b0ct.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pwf4b0ct.sc.entry.js",
		"common",
		46
	],
	"./qvwswew4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvwswew4.entry.js",
		"common",
		117
	],
	"./qvwswew4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvwswew4.sc.entry.js",
		"common",
		118
	],
	"./rjuj7fe1.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rjuj7fe1.entry.js",
		"common",
		47
	],
	"./rjuj7fe1.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rjuj7fe1.sc.entry.js",
		"common",
		48
	],
	"./rwsekq0d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rwsekq0d.entry.js",
		"common",
		93
	],
	"./rwsekq0d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rwsekq0d.sc.entry.js",
		"common",
		94
	],
	"./rzti7vhz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rzti7vhz.entry.js",
		"common",
		95
	],
	"./rzti7vhz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rzti7vhz.sc.entry.js",
		"common",
		96
	],
	"./s1oi7icr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s1oi7icr.entry.js",
		0,
		"common",
		161
	],
	"./s1oi7icr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s1oi7icr.sc.entry.js",
		0,
		"common",
		162
	],
	"./srmtwcfh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/srmtwcfh.entry.js",
		"common",
		97
	],
	"./srmtwcfh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/srmtwcfh.sc.entry.js",
		"common",
		98
	],
	"./ssac3xh9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ssac3xh9.entry.js",
		"common",
		49
	],
	"./ssac3xh9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ssac3xh9.sc.entry.js",
		"common",
		50
	],
	"./t547wlk7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/t547wlk7.entry.js",
		"common",
		119
	],
	"./t547wlk7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/t547wlk7.sc.entry.js",
		"common",
		120
	],
	"./tix2rxyu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tix2rxyu.entry.js",
		"common",
		99
	],
	"./tix2rxyu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tix2rxyu.sc.entry.js",
		"common",
		100
	],
	"./vf5uvhxb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vf5uvhxb.entry.js",
		"common",
		101
	],
	"./vf5uvhxb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vf5uvhxb.sc.entry.js",
		"common",
		102
	],
	"./voah5ut7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/voah5ut7.entry.js",
		"common",
		103
	],
	"./voah5ut7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/voah5ut7.sc.entry.js",
		"common",
		104
	],
	"./wmec5hay.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wmec5hay.entry.js",
		"common",
		105
	],
	"./wmec5hay.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wmec5hay.sc.entry.js",
		"common",
		106
	],
	"./xjhsjpg5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xjhsjpg5.entry.js",
		0,
		"common",
		163
	],
	"./xjhsjpg5.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xjhsjpg5.sc.entry.js",
		0,
		"common",
		164
	],
	"./xphsuoxm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xphsuoxm.entry.js",
		"common",
		73
	],
	"./xphsuoxm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xphsuoxm.sc.entry.js",
		"common",
		74
	],
	"./xqpitku0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xqpitku0.entry.js",
		"common",
		51
	],
	"./xqpitku0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xqpitku0.sc.entry.js",
		"common",
		52
	],
	"./yf92ghnn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yf92ghnn.entry.js",
		0,
		"common",
		121
	],
	"./yf92ghnn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yf92ghnn.sc.entry.js",
		0,
		"common",
		122
	],
	"./z9nt6ntd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9nt6ntd.entry.js",
		"common",
		129
	],
	"./z9nt6ntd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9nt6ntd.sc.entry.js",
		"common",
		130
	],
	"./zbmjxgef.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zbmjxgef.entry.js",
		"common",
		53
	],
	"./zbmjxgef.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zbmjxgef.sc.entry.js",
		"common",
		54
	],
	"./zejxbv2g.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zejxbv2g.entry.js",
		"common",
		107
	],
	"./zejxbv2g.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zejxbv2g.sc.entry.js",
		"common",
		108
	],
	"./zfesn3pp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zfesn3pp.entry.js",
		"common",
		109
	],
	"./zfesn3pp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zfesn3pp.sc.entry.js",
		"common",
		110
	],
	"./zsvoinsq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zsvoinsq.entry.js",
		"common",
		55
	],
	"./zsvoinsq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zsvoinsq.sc.entry.js",
		"common",
		56
	],
	"./zy1y1btp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zy1y1btp.entry.js",
		"common",
		111
	],
	"./zy1y1btp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zy1y1btp.sc.entry.js",
		"common",
		112
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./home/home.module": [
		"./src/app/home/home.module.ts",
		"default~home-home-module~home1-home1-module~home2-home2-module~login-login-module~main-main-module~t~117a6ada",
		"common",
		"home-home-module"
	],
	"./home1/home1.module": [
		"./src/app/home1/home1.module.ts",
		"default~home-home-module~home1-home1-module~home2-home2-module~login-login-module~main-main-module~t~117a6ada",
		"common",
		"home1-home1-module"
	],
	"./home2/home2.module": [
		"./src/app/home2/home2.module.ts",
		"default~home-home-module~home1-home1-module~home2-home2-module~login-login-module~main-main-module~t~117a6ada",
		"common",
		"home2-home2-module"
	],
	"./login/login.module": [
		"./src/app/login/login.module.ts",
		"default~home-home-module~home1-home1-module~home2-home2-module~login-login-module~main-main-module~t~117a6ada",
		"common",
		"login-login-module"
	],
	"./main/main.module": [
		"./src/app/main/main.module.ts",
		"default~home-home-module~home1-home1-module~home2-home2-module~login-login-module~main-main-module~t~117a6ada",
		"common",
		"main-main-module"
	],
	"./testgame/testgame.module": [
		"./src/app/testgame/testgame.module.ts",
		"default~home-home-module~home1-home1-module~home2-home2-module~login-login-module~main-main-module~t~117a6ada",
		"common",
		"testgame-testgame-module"
	],
	"./testgame2/testgame2.module": [
		"./src/app/testgame2/testgame2.module.ts",
		"testgame2-testgame2-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'home', loadChildren: './home/home.module#HomePageModule' },
    { path: 'testgame', loadChildren: './testgame/testgame.module#TestgamePageModule' },
    { path: 'testgame2', loadChildren: './testgame2/testgame2.module#Testgame2PageModule' },
    { path: 'home1', loadChildren: './home1/home1.module#Home1PageModule' },
    { path: 'main', loadChildren: './main/main.module#MainPageModule' },
    { path: 'home2', loadChildren: './home2/home2.module#Home2PageModule' },
    { path: 'login', loadChildren: './login/login.module#LoginPageModule' },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__["StatusBar"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
            entryComponents: [],
            imports: [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"]],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/pnguyen/IonicApp/spaceApp/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map